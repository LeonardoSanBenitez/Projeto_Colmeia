// User defined code goes here
////
//
//  The following was automatically appended by the Wisc-Online upload system.
//
////
////
////
//
// Set the global background color variable
// to whatever the current background is
// This should result in a transparent background
g_strBgColor = document.bgColor;
