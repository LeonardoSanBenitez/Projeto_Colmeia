(function($) {
	/***************************************************************
	****                    BOTÕES CENTRAIS                     ****
	***************************************************************/
	proximo = function(img){
		var element = document.getElementById(img).src;
		var src = element.substr(element.lastIndexOf('/') + 1, element.length);
		/** Hall **/
		if (src == 'hall.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/escada_0.jpg';
			$("#anterior").show("slow", "swing");
			$("#proximo").hide("slow", "swing");
		} 
		/** DAELN **/
		else if (src == 'escada_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/escada_2.jpg';
			$("#esquerda").show("slow", "swing");
			$("#proximo").hide("slow", "swing");
			$("#direita").show("slow", "swing");	
		} else if (src == 'corredor_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_2.jpg';
			$("#anterior").show("slow", "swing");
			$("#esquerda").hide("slow", "swing");
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");	
		} else if (src == 'corredor_2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_3.jpg';	
		} else if (src == 'corredor_3.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_4.jpg';	
		} else if (src == 'corredor_4.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_5.jpg';	
		} else if (src == 'corredor_5.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_6.jpg';	
		} else if (src == 'corredor_6.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_7.jpg';	
		} else if (src == 'corredor_7.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_8.jpg';	
		} else if (src == 'corredor_8.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lab_smm2.jpg';	
			$("#direita").hide("slow", "swing");
			$("#proximo").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
			$("#experimento").show("slow", "swing");
		} 
		/** Praça, Lazer e Ginásio **/
		else if (src == 'praca_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lazer_1.jpg';	
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
		} else if (src == 'lazer_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lazer_2.jpg';	
			$("#direita").hide("slow", "swing");
		} else if (src == 'lazer_2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/ginasio_1.jpg';	
			$("#esquerda").show("slow", "swing");
			$("#direita").show("slow", "swing");
		} else if (src == 'ginasio_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/ginasio_3.jpg';	
			$("#esquerda").hide("slow", "swing");
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
		}
		
		//Ativa o loading se, apos 200ms, a imagem ainda nao tiver carregado 
		setTimeout(function(){
			var x = document.getElementById(img).complete;
			if(x){
				$("#loading").hide("fast", "swing");
			} else{
				$("#loading").show("fast", "swing");
			}
		}, 500);
	} 	

	anterior = function(img){
		var element = document.getElementById(img).src;
		var src = element.substr(element.lastIndexOf('/') + 1, element.length);
		/** DAELN **/
		if (src == 'escada_0.jpg'){
			document.getElementById(img).src = 'recursos/imagens/hall.jpg';
			$("#anterior").hide("slow", "swing");
			$("#proximo").show("slow", "swing");
		} else if (src == 'escada_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/escada_0.jpg';
			$("#esquerda").show("slow", "swing");	
			$("#proximo").hide("slow", "swing");
			$("#direita").show("slow", "swing");
		} else if (src == 'escada_2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/escada_1.jpg';
			$("#esquerda").hide("slow", "swing");	
			$("#proximo").show("slow", "swing");
			$("#direita").hide("slow", "swing");
		} else if (src == 'corredor_0.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/escada_2.jpg';
		} else if (src == 'corredor_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/escada_2.jpg';
			$("#esquerda").show("slow", "swing");	
			$("#proximo").hide("slow", "swing");
			$("#direita").show("slow", "swing");
		} else if (src == 'corredor_2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_1.jpg';
			$("#direita").hide("slow", "swing");
		} else if (src == 'corredor_3.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_2.jpg';
		} else if (src == 'corredor_4.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_3.jpg';
		} else if (src == 'corredor_5.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_4.jpg';
		} else if (src == 'corredor_6.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_5.jpg';
		} else if (src == 'corredor_7.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_6.jpg';
		} else if (src == 'corredor_8.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_7.jpg';
		} else if (src == 'lab_smm2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_8.jpg';
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
			$("#experimento").hide("slow", "swing");
		} else if (src == 'lab_dsp.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_8.jpg';
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
			$("#experimento").hide("slow", "swing");
		} else if (src == 'lab_mcp.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_7.jpg';
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
			$("#experimento").hide("slow", "swing");
		} else if (src == 'lab_elp.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_6.jpg';
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
			$("#experimento").hide("slow", "swing");
		} else if (src == 'lab_eld.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_5.jpg';
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
			$("#experimento").hide("slow", "swing");
		} else if (src == 'lab_lpt.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_4.jpg';
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
			$("#experimento").hide("slow", "swing");
		} else if (src == 'lab_ld2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_3.jpg';
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
			$("#experimento").hide("slow", "swing");
		} else if (src == 'lab_ld1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_2.jpg';
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
			$("#experimento").hide("slow", "swing");
		} else if (src == 'corredor_sul_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_0.jpg';
			$("#esquerda").show("slow", "swing");
			$("#direita").show("slow", "swing");
		} else if (src == 'corredor_norte_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_0.jpg';
			$("#esquerda").show("slow", "swing");
			$("#direita").show("slow", "swing");
		} 
		/** Praça, Lazer e Ginásio **/
		else if (src == 'praca_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/hall.jpg';
			$("#anterior").hide("slow", "swing");
			$("#esquerda").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
		} else if (src == 'lazer_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/praca_1.jpg';
			$("#esquerda").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
		} else if (src == 'lazer_2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lazer_1.jpg';
			$("#direita").show("slow", "swing");
		} else if (src == 'ginasio_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lazer_2.jpg';
			$("#esquerda").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
		} else if (src == 'ginasio_3.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/ginasio_1.jpg';
			$("#direita").show("slow", "swing");
			$("#esquerda").show("slow", "swing");
			$("#proximo").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
		} else if (src == 'ginasio_2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/ginasio_1.jpg';
			$("#direita").show("slow", "swing");
			$("#esquerda").show("slow", "swing");
			$("#proximo").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
		} else if (src == 'ginasio_4.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/ginasio_1.jpg';
			$("#direita").show("slow", "swing");
			$("#esquerda").show("slow", "swing");
			$("#proximo").show("slow", "swing");
		}
		/** Biblioteca **/
		else if (src == 'biblioteca.jpg'){
			document.getElementById(img).src = 'recursos/imagens/hall.jpg';
			$("#anterior").hide("slow", "swing");
			$("#esquerda").show("slow", "swing");
			$("#proximo").show("slow", "swing");
			$("#direita").show("slow", "swing");
			$("#info").hide("slow", "swing");
			$("#ver360").hide("slow", "swing");
		}
		
		//Ativa o loading se, apos 200ms, a imagem ainda nao tiver carregado 
		setTimeout(function(){
			var x = document.getElementById(img).complete;
			if(x){
				$("#loading").hide("fast", "swing");
			} else{
				$("#loading").show("fast", "swing");
			}
		}, 500);
	}
		
	direita = function(img){
		var element = document.getElementById(img).src;
		var src = element.substr(element.lastIndexOf('/') + 1, element.length);
		/** Hall **/
		if (src == 'hall.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/biblioteca.jpg';
			$("#anterior").show("slow", "swing");
			$("#esquerda").hide("slow", "swing");
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
		} 
		/** DAELN **/
		else if (src == 'escada_0.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/escada_1.jpg';
			$("#esquerda").hide("slow", "swing");
			$("#proximo").show("slow", "swing");
			$("#direita").hide("slow", "swing");	
		} else if (src == 'escada_2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_1.jpg';
			$("#anterior").show("slow", "swing");
			$("#esquerda").hide("slow", "swing");
			$("#proximo").show("slow", "swing");
			$("#direita").hide("slow", "swing");	
		} else if (src == 'corredor_2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lab_ld1.jpg';
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
			$("#experimento").show("slow", "swing");			
		} else if (src == 'corredor_3.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lab_ld2.jpg';
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");	
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
			$("#experimento").show("slow", "swing");
		} else if (src == 'corredor_4.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lab_lpt.jpg';
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
			$("#experimento").show("slow", "swing");			
		} else if (src == 'corredor_5.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lab_eld.jpg';
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
			$("#experimento").show("slow", "swing");			
		} else if (src == 'corredor_6.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lab_elp.jpg';
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
			$("#experimento").show("slow", "swing");			
		} else if (src == 'corredor_7.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lab_mcp.jpg';
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
			$("#experimento").show("slow", "swing");			
		} else if (src == 'corredor_8.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lab_dsp.jpg';
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
			$("#experimento").show("slow", "swing");			
		} else if (src == 'corredor_0.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_norte_1.jpg';
			$("#direita").hide("slow", "swing");
			$("#esquerda").hide("slow", "swing");
		} 
		/** Praça, Lazer e Ginásio **/
		else if (src == 'lazer_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/escada_0.jpg';
			$("#esquerda").show("slow", "swing");
			$("#proximo").hide("slow", "swing");
		} else if (src == 'ginasio_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/ginasio_4.jpg';
			$("#esquerda").hide("slow", "swing");
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
		}
		
		//Ativa o loading se, apos 200ms, a imagem ainda nao tiver carregado 
		setTimeout(function(){
			var x = document.getElementById(img).complete;
			if(x){
				$("#loading").hide("fast", "swing");
			} else{
				$("#loading").show("fast", "swing");
			}
		}, 500);
	}
	
	esquerda = function(img){
		var element = document.getElementById(img).src;
		var src = element.substr(element.lastIndexOf('/') + 1, element.length);
		/** DAELN **/
		if (src == 'escada_0.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/lazer_1.jpg';
			$("#esquerda").hide("slow", "swing");
			$("#proximo").show("slow", "swing");
		} else if (src == 'escada_2.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_0.jpg';
			$("#anterior").show("slow", "swing");
		} else if (src == 'corredor_0.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/corredor_sul_1.jpg';
			$("#direita").hide("slow", "swing");
			$("#esquerda").hide("slow", "swing");
		} 
		/** Praça, Lazer e Ginásio **/
		else if (src == 'hall.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/praca_1.jpg';
			$("#anterior").show("slow", "swing");
			$("#esquerda").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
		} else if (src == 'ginasio_1.jpg'){
			document.getElementById(img).src = 'recursos/imagens/tour_virtual/ginasio_2.jpg';
			$("#esquerda").hide("slow", "swing");
			$("#proximo").hide("slow", "swing");
			$("#direita").hide("slow", "swing");
			$("#info").show("slow", "swing");
			$("#ver360").show("slow", "swing");
		}
		
		//Ativa o loading se, apos 200ms, a imagem ainda nao tiver carregado 
		setTimeout(function(){
			var x = document.getElementById(img).complete;
			if(x){
				$("#loading").hide("fast", "swing");
			} else{
				$("#loading").show("fast", "swing");
			}
		}, 500);
	}
	
	/***************************************************************
	****                   BOTÕES INFERIORES                    ****
	***************************************************************/
	info = function(){
		$(".popUp").show("slow", "swing");
	}
	
	ver360 = function(){
		$(".popUp").show("slow", "swing");
	}
	
	experimento = function(){
		$(".popUp").show("slow", "swing");
	}
	
	fechar = function(){
		$(".popUp").hide("slow", "swing");
	}

}(jQuery));

